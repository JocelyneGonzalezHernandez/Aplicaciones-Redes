package com.example.exa1_jos

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.os.CountDownTimer
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.example.exa1_jos.R
import kotlin.random.Random

lateinit var editTextNumeros: EditText
lateinit var valida:Button
lateinit var textViewNumbers: TextView

class jugar : AppCompatActivity() {
    private var randomNumber: Int = 0
    private var puntaje: Int = 0
    private var vidas: Int = 3
    private val numbersList = mutableListOf<Int>() // Lista para almacenar números generados

    private lateinit var textViewPuntos: TextView
    private lateinit var textViewVidas: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_jugar)

        val textViewTempo = findViewById<TextView>(R.id.tempo)
        textViewNumbers = findViewById(R.id.secuencia)
        editTextNumeros = findViewById(R.id.numeros)
        valida = findViewById(R.id.buttonValidar)
        textViewPuntos = findViewById(R.id.puntos)
        textViewVidas = findViewById(R.id.vidas)

        // Inicia el temporizador y mantiene el EditText y el botón deshabilitados
        editTextNumeros.isEnabled = false
        valida.isEnabled = false
        startTimer(textViewTempo)

        valida.setOnClickListener {
            validateInput() // Llamar a la función de validación
        }
    }

    private fun startTimer(textView: TextView) {
        randomNumber = generateRandomNumber()
        //numbersList.clear() // Limpiar la lista antes de empezar
        numbersList.add(randomNumber) // Agregar el primer número a la lista
        //updateNumberTextView() // Actualizar el TextView con el número

        object : CountDownTimer(5000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                textView.text = "Tiempo restante: ${millisUntilFinished / 1000} segundos"
                textViewNumbers.text = randomNumber.toString()
                textViewNumbers.visibility = TextView.VISIBLE
                updateNumberTextView()
            }

            override fun onFinish() {
                textView.text = "¡Tiempo terminado!"
                editTextNumeros.isEnabled = true // Habilitar el EditText
                valida.isEnabled = true // Habilitar el botón
                textViewNumbers.visibility = TextView.GONE
            }
        }.start()
    }

    private fun generateRandomNumber(): Int {
        return Random.nextInt(0, 101)
    }

    private fun validateInput() {
        val userInput = editTextNumeros.text.toString()
        if (userInput.isNotEmpty()) {
            val userNumber = userInput.toIntOrNull()
            if (userNumber != null) {
                if (userNumber == randomNumber) {
                    puntaje++
                    Toast.makeText(this, "¡Correcto!", Toast.LENGTH_SHORT).show()
                    randomNumber = generateRandomNumber() // Generar un nuevo número
                    numbersList.add(randomNumber) // Agregar el nuevo número a la lista
                    updateNumberTextView() // Actualizar el TextView con la lista de números
                    editTextNumeros.text.clear() // Limpiar el EditText
                    editTextNumeros.isEnabled = false
                    valida.isEnabled = false
                    startTimer(findViewById(R.id.tempo)) // Reiniciar el temporizador
                } else {
                    if (vidas > 0) {
                        vidas--
                        Toast.makeText(this, "Incorrecto, intenta nuevamente.", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "No tienes más vidas.", Toast.LENGTH_SHORT).show()
                    }
                }
                updateUI() // Actualizar la interfaz
            } else {
                Toast.makeText(this, "Por favor, ingresa un número válido.", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Por favor, ingresa un número.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateUI() {
        textViewPuntos.text = "Puntaje: $puntaje"
        textViewVidas.text = "Vidas restantes: $vidas"
    }

    private fun updateNumberTextView() {
        textViewNumbers.text = numbersList.joinToString(", ") // Mostrar todos los números generados
    }
}
