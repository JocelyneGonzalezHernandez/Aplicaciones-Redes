package com.example.exa1_jos

import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class culturizate : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_culturizate)

        val nombre = intent.getStringExtra("nombre")
        val fechaNacimiento = intent.getStringExtra("fecha_nacimiento")
        val lugarNacimiento = intent.getStringExtra("lugar_nacimiento")
        val descripcion = intent.getStringExtra("descripcion")

        val infoTextView = findViewById<TextView>(R.id.infoTextView)
        val info = """
            Nombre: $nombre
            Fecha de Nacimiento: $fechaNacimiento
            Lugar de Nacimiento: $lugarNacimiento
            Descripción: $descripcion
        """.trimIndent()

        infoTextView.text = info
    }
}