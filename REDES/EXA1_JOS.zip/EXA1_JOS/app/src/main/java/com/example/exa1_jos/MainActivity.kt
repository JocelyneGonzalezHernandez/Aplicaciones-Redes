package com.example.exa1_jos

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONObject
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

    }

    fun botonJugar(view: View) {
        val btJugar = findViewById<Button>(R.id.buttonJugar)
        val jugador = findViewById<EditText>(R.id.nombre)

        val textoIngresado = jugador.text.toString()
        val nombreJugador = intent.getStringExtra("nombre")

        if (textoIngresado.isEmpty()) {
            // Muestra un mensaje si el campo está vacío
            Toast.makeText(this, "Por favor, ingresa un nombre para jugar.", Toast.LENGTH_SHORT).show()
        } else {
            // Si el campo no está vacío, pasa a la siguiente pantalla
            val intent = Intent(this, jugar::class.java)
            startActivity(intent)



        }
    }

    fun botonPuntaje(view: View) {
        val btpuntajes = findViewById<Button>(R.id.buttonPunt)
        val intent = Intent(this, puntajes::class.java)
        startActivity(intent)

    }

    fun botonCulturizate(view: View) {
        val btCultu = findViewById<Button>(R.id.buttonCult)

        // Leer el archivo JSON de assets
        val jsonString = assets.open("memoria_prodigio.json").bufferedReader().use { it.readText() }

        // Parsear el JSON
        val jsonObject = JSONObject(jsonString)
        val memoriaProdigio = jsonObject.getJSONArray("memoria_prodigio")

        // Seleccionar un registro aleatorio
        val randomIndex = Random.nextInt(memoriaProdigio.length())
        val randomProdigio = memoriaProdigio.getJSONObject(randomIndex)

        // Extraer los datos del prodigio seleccionado
        val nombre = randomProdigio.getString("nombre")
        val fechaNacimiento = randomProdigio.getString("fecha_nacimiento")
        val lugarNacimiento = randomProdigio.getString("lugar_nacimiento")
        val descripcion = randomProdigio.getString("descripcion")

        // Iniciar la nueva actividad pasando los datos
        val intent = Intent(this, culturizate::class.java)
        intent.putExtra("nombre", nombre)
        intent.putExtra("fecha_nacimiento", fechaNacimiento)
        intent.putExtra("lugar_nacimiento", lugarNacimiento)
        intent.putExtra("descripcion", descripcion)
        startActivity(intent)
    }

}