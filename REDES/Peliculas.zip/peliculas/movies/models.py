from django.db import models

class Movie(models.Model):
    title = models.CharField(max_length=100)
    director = models.CharField(max_length=100)
    classification = models.CharField(max_length=20)
    release_year = models.IntegerField()
    duration = models.IntegerField()
    genres = models.CharField(max_length=100)
